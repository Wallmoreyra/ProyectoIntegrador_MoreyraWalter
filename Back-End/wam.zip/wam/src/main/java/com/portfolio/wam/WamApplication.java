package com.portfolio.wam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WamApplication {

	public static void main(String[] args) {
		SpringApplication.run(WamApplication.class, args);
	}

}
