package com.portfolio.wam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WamApplicationTests {

	@Test
	void contextLoads() {
	}

}
